#![no_std]
#![no_main]

use core::panic::PanicInfo;
use bootloader::{entry_point, BootInfo};
use core::arch::asm;
use font8x8::UnicodeFonts;

#[inline]
unsafe fn outb(port: u16, val: u8) {
    asm!("out dx, al", in("dx") port, in("al") val, options(nomem, nostack, preserves_flags));
}

#[inline]
unsafe fn inb(port: u16) -> u8 {
    let val: u8;
    asm!("in al, dx", out("al") val, in("dx") port, options(nomem, nostack, preserves_flags));
    val
}

#[inline]
unsafe fn hlt() {
    asm!("hlt", options(nomem, nostack, preserves_flags));
}

#[inline]
unsafe fn sti() {
    asm!("sti", options(nomem, nostack, preserves_flags));
}

// ---- PC SPEAKER AUDIO ----
unsafe fn play_sound(frequency: u32) {
    let div = 1193180 / frequency;
    outb(0x43, 0xB6); // Command for channel 2, square wave
    outb(0x42, (div & 0xFF) as u8); // Data low byte
    outb(0x42, (div >> 8) as u8); // Data high byte
    
    let tmp = inb(0x61);
    if tmp != (tmp | 3) {
        outb(0x61, tmp | 3); // Enable speaker
    }
}

unsafe fn stop_sound() {
    let tmp = inb(0x61) & 0xFC; // Disable speaker
    outb(0x61, tmp);
}
// --------------------------

#[derive(Clone, Copy)]
#[repr(C, packed)]
struct IdtDescriptor {
    offset_low: u16,
    selector: u16,
    ist: u8,
    type_attr: u8,
    offset_mid: u16,
    offset_high: u32,
    ignore: u32,
}

#[repr(C, packed)]
struct Idtr {
    limit: u16,
    base: u64,
}

static mut IDT: [IdtDescriptor; 256] = [IdtDescriptor {
    offset_low: 0,
    selector: 0,
    ist: 0,
    type_attr: 0,
    offset_mid: 0,
    offset_high: 0,
    ignore: 0,
}; 256];

#[inline]
unsafe fn get_cs() -> u16 {
    let cs: u16;
    asm!("mov {:x}, cs", out(reg) cs, options(nomem, nostack, preserves_flags));
    cs
}

fn set_idt_entry(index: usize, handler: unsafe extern "C" fn()) {
    let handler_addr = handler as u64;
    unsafe {
        IDT[index].offset_low = handler_addr as u16;
        IDT[index].selector = get_cs(); // Dynamically get the current Code Segment
        IDT[index].ist = 0;
        IDT[index].type_attr = 0x8E; // Interrupt Gate, Present, DPL 0
        IDT[index].offset_mid = (handler_addr >> 16) as u16;
        IDT[index].offset_high = (handler_addr >> 32) as u32;
        IDT[index].ignore = 0;
    }
}

core::arch::global_asm!(
    ".global timer_int_wrapper",
    "timer_int_wrapper:",
    "push rax\n push rcx\n push rdx\n push rsi\n push rdi\n push r8\n push r9\n push r10\n push r11\n",
    "call timer_handler",
    "pop r11\n pop r10\n pop r9\n pop r8\n pop rdi\n pop rsi\n pop rdx\n pop rcx\n pop rax\n",
    "iretq"
);

core::arch::global_asm!(
    ".global kb_int_wrapper",
    "kb_int_wrapper:",
    "push rax\n push rcx\n push rdx\n push rsi\n push rdi\n push r8\n push r9\n push r10\n push r11\n",
    "call kb_handler",
    "pop r11\n pop r10\n pop r9\n pop r8\n pop rdi\n pop rsi\n pop rdx\n pop rcx\n pop rax\n",
    "iretq"
);

extern "C" {
    fn timer_int_wrapper();
    fn kb_int_wrapper();
}

static mut TICK: u32 = 0;

#[no_mangle]
extern "C" fn timer_handler() {
    unsafe {
        TICK = TICK.wrapping_add(1);
        outb(0x20, 0x20); // End of Interrupt to Master PIC
    }
}

static mut KEY_W: bool = false;
static mut KEY_S: bool = false;
static mut KEY_UP: bool = false;
static mut KEY_DOWN: bool = false;

#[no_mangle]
extern "C" fn kb_handler() {
    unsafe {
        let scancode = inb(0x60);
        match scancode {
            0x11 => KEY_W = true,
            0x91 => KEY_W = false,
            0x1F => KEY_S = true,
            0x9F => KEY_S = false,
            0x48 => KEY_UP = true,
            0xC8 => KEY_UP = false,
            0x50 => KEY_DOWN = true,
            0xD0 => KEY_DOWN = false,
            _ => {}
        }
        outb(0x20, 0x20);
    }
}

unsafe fn init_pic_and_idt() {
    let m_cmd = 0x20; let m_data = 0x21;
    let s_cmd = 0xA0; let s_data = 0xA1;

    outb(m_cmd, 0x11);
    outb(s_cmd, 0x11);
    outb(m_data, 32); 
    outb(s_data, 40);
    outb(m_data, 4); 
    outb(s_data, 2); 
    outb(m_data, 0x01);
    outb(s_data, 0x01);
    
    outb(m_data, 0b1111_1100); 
    outb(s_data, 0b1111_1111);

    set_idt_entry(32, timer_int_wrapper);
    set_idt_entry(33, kb_int_wrapper);

    let idtr = Idtr {
        limit: (256 * 16) - 1,
        base: IDT.as_ptr() as u64,
    };
    asm!("lidt [{}]", in(reg) &idtr, options(readonly, nostack, preserves_flags));
    sti();
}

// ---- RENDERING HELPERS ----
fn draw_char(buffer: &mut [u8; 320*200], x: usize, y: usize, c: char, color: u8, scale: usize) {
    if let Some(glyph) = font8x8::BASIC_FONTS.get(c) {
        for (row_idx, row) in glyph.iter().enumerate() {
            for col_idx in 0..8 {
                if (row & (1 << col_idx)) != 0 {
                    for sy in 0..scale {
                        for sx in 0..scale {
                            let px = x + (col_idx * scale) + sx;
                            let py = y + (row_idx * scale) + sy;
                            if px < 320 && py < 200 {
                                buffer[py * 320 + px] = color;
                            }
                        }
                    }
                }
            }
        }
    }
}

fn draw_score(buffer: &mut [u8; 320*200], x: usize, y: usize, mut score: u32) {
    if score == 0 {
        draw_char(buffer, x, y, '0', 0x0F, 2);
        return;
    }
    let mut digits = [0u8; 10];
    let mut count = 0;
    while score > 0 {
        digits[count] = (score % 10) as u8;
        score /= 10;
        count += 1;
    }
    for i in 0..count {
        let digit_char = (digits[count - 1 - i] + b'0') as char;
        draw_char(buffer, x + (i * 20), y, digit_char, 0x0F, 2);
    }
}
// ---------------------------

entry_point!(kernel_main);

fn kernel_main(_boot_info: &'static BootInfo) -> ! {
    unsafe { init_pic_and_idt(); }

    let vga_buffer = 0xA0000 as *mut u8;
    let mut backbuffer = [0u8; 320 * 200];

    let mut ball_x: i32 = 160 * 100;
    let mut ball_y: i32 = 100 * 100;
    let mut ball_dx: i32 = -400; // Start moving left
    let mut ball_dy: i32 = 300; 

    let mut p1_y: i32 = 80 * 100;
    let mut p2_y: i32 = 80 * 100;
    
    let paddle_h: i32 = 40 * 100;
    let paddle_speed: i32 = 800;
    let ai_speed: i32 = 400; // Slower than player so it's beatable
    
    let mut score1: u32 = 0;
    let mut score2: u32 = 0;

    let mut last_tick = 0;
    let mut beep_timer = 0;

    loop {
        unsafe { hlt(); }
        let current_tick = unsafe { core::ptr::read_volatile(core::ptr::addr_of!(TICK)) };
        if current_tick == last_tick { continue; }
        last_tick = current_tick;

        if beep_timer > 0 {
            beep_timer -= 1;
            if beep_timer == 0 {
                unsafe { stop_sound(); }
            }
        }

        // P1 Input (Human)
        let w = unsafe { core::ptr::read_volatile(core::ptr::addr_of!(KEY_W)) };
        let s = unsafe { core::ptr::read_volatile(core::ptr::addr_of!(KEY_S)) };
        if w { p1_y -= paddle_speed; }
        if s { p1_y += paddle_speed; }

        // P2 Input (AI)
        let center_p2 = p2_y + (paddle_h / 2);
        if ball_dx > 0 { // Ball moving towards AI
            if ball_y > center_p2 + 500 {
                p2_y += ai_speed;
            } else if ball_y < center_p2 - 500 {
                p2_y -= ai_speed;
            }
        } else { // Ball moving away, return to center
            let center_screen = 100 * 100;
            if center_p2 < center_screen - 500 {
                p2_y += ai_speed / 2;
            } else if center_p2 > center_screen + 500 {
                p2_y -= ai_speed / 2;
            }
        }

        if p1_y < 0 { p1_y = 0; }
        if p1_y > (200 * 100) - paddle_h { p1_y = (200 * 100) - paddle_h; }
        if p2_y < 0 { p2_y = 0; }
        if p2_y > (200 * 100) - paddle_h { p2_y = (200 * 100) - paddle_h; }

        ball_x += ball_dx;
        ball_y += ball_dy;

        // Bounce Top/Bottom
        if ball_y <= 0 || ball_y >= (198 * 100) {
            ball_dy = -ball_dy;
            unsafe { play_sound(400); } // Wall bounce sound
            beep_timer = 2;
        }

        // Bounce Left Paddle
        if ball_dx < 0 && ball_x <= 14 * 100 && ball_x >= 4 * 100 {
            if ball_y + (2*100) >= p1_y && ball_y <= p1_y + paddle_h {
                ball_dx = 500; 
                ball_dy += if ball_y < p1_y + (paddle_h/2) { -150 } else { 150 };
                unsafe { play_sound(800); } // Paddle bounce
                beep_timer = 2;
            }
        }

        // Bounce Right Paddle
        if ball_dx > 0 && ball_x >= 304 * 100 && ball_x <= 316 * 100 {
            if ball_y + (2*100) >= p2_y && ball_y <= p2_y + paddle_h {
                ball_dx = -500; 
                ball_dy += if ball_y < p2_y + (paddle_h/2) { -150 } else { 150 };
                unsafe { play_sound(800); } // Paddle bounce
                beep_timer = 2;
            }
        }

        // Reset if scored
        if ball_x < 0 || ball_x > 320 * 100 {
            if ball_x < 0 {
                score2 += 1;
                unsafe { play_sound(200); } // Lose tone
            } else {
                score1 += 1;
                unsafe { play_sound(1200); } // Win tone
            }
            beep_timer = 5;
            ball_x = 160 * 100;
            ball_y = 100 * 100;
            ball_dx = if ball_dx > 0 { -400 } else { 400 };
            ball_dy = 300;
        }

        // Clear background
        for i in 0..(320*200) { backbuffer[i] = 0x00; }

        // Draw Center Net
        for y in (0..200).step_by(10) {
            for h in 0..5 {
                if y+h < 200 { backbuffer[(y+h)*320 + 160] = 0x08; }
            }
        }

        // Draw Scores
        draw_score(&mut backbuffer, 120, 20, score1);
        draw_score(&mut backbuffer, 180, 20, score2);

        // Draw P1
        let p1_px = (p1_y / 100) as usize;
        for y in p1_px..(p1_px + 40) {
            for x in 10..14 {
                if y < 200 { backbuffer[y * 320 + x] = 0x0F; }
            }
        }

        // Draw P2
        let p2_px = (p2_y / 100) as usize;
        for y in p2_px..(p2_px + 40) {
            for x in 306..310 {
                if y < 200 { backbuffer[y * 320 + x] = 0x0F; }
            }
        }

        // Draw Ball (3x3)
        let bx = (ball_x / 100).max(0) as usize;
        let by = (ball_y / 100).max(0) as usize;
        for y in by..(by + 3) {
            for x in bx..(bx + 3) {
                if x < 320 && y < 200 { backbuffer[y * 320 + x] = 0x0E; }
            }
        }

        unsafe {
            core::ptr::copy_nonoverlapping(backbuffer.as_ptr(), vga_buffer, 320 * 200);
        }
    }
}

#[panic_handler]
fn panic(_info: &PanicInfo) -> ! {
    loop {
        unsafe { hlt(); }
    }
}
